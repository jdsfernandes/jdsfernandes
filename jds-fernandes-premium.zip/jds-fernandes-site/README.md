# JDS Fernandes — Website

Site completo em HTML/CSS/JS, em português de Portugal, preparado para GitHub Pages.

## Ficheiros
- `index.html` — conteúdo e estrutura
- `style.css` — design responsivo amarelo/preto
- `script.js` — menu mobile e formulário que envia o pedido pelo WhatsApp

## Publicar no GitHub Pages
1. Crie/abra o repositório `jdsfernandes`.
2. Envie estes três ficheiros para a raiz do repositório.
3. Em Settings > Pages, selecione a branch principal e `/root`.
4. O site ficará disponível no endereço do GitHub Pages.

## Fotografias
Os blocos da galeria e a imagem principal estão preparados como placeholders. Pode substituir os blocos por fotografias reais dos trabalhos quando quiser.
